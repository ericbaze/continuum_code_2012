=== [GWA] db Editor ===
Contributors: pomspot
Donate link: http://code4cookies.com/
Tags: database editor, database, editor,db edit, db
Requires at least: 2.5
Tested up to: 3.0.1
Stable tag: 1.1

A plugin to access and edit all your database fields.

== Description ==

A dangerously powerful plugin that will allow you to access and update your database tables in your weblog administrator. Uses TableKit. 

*   Access and update your database fields.
*   Uses AJAX and TableKit to update field data.
*   Simple and fast. Just click, edit, and submit.
*   CAUTION: If you do not know what you are doing DO NOT INSTALL THIS PLUG-IN.
*   WARNING: This plugin can accidentally disable your blog with one click.
*   DISCLAIMER: The author of this plugin takes no responsibility for its use.

== Installation ==

1. If you aren't sure then PLEASE don't!
 
== Screenshots ==

1. Database field editing with TableKit.
