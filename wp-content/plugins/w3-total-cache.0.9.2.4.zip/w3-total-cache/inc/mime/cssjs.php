<?php

/**
 * CSS and JS mime types
 */
return array(
    'css' => 'text/css', 
    'js' => 'application/x-javascript',
    'htc' => 'text/x-component'
);
